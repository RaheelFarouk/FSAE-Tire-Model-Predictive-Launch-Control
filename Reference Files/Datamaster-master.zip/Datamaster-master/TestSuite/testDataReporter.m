%% Constructor
dr = DataReporter;
assert(isa(dr, 'DataReporter'))

%% Refresh Datastore
dr = DataReporter;
dr.RefreshDatastore;
