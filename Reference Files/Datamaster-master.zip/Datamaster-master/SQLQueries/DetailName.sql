CREATE TABLE DetailName(
	id 				INTEGER 		PRIMARY KEY,
	fieldName 		TEXT			NOT NULL
)